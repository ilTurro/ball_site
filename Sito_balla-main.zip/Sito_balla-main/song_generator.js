function generate_number (){
    document.getElementById("Sium").innerHTML = Math.floor(Math.random() * 30) + 1;
}